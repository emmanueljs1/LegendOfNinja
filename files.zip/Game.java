import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.*;

public class Game implements Runnable {

    @Override
    public void run() {

        final JFrame frame = new JFrame("The Legend of Ninja");
        frame.setLocation(300, 300);
        
        String[] stageFilenames = {"background.png", "background1.png", "background2.png"};
        Enemy[] enemyTypes = {Enemy.RedNinja, Enemy.BlueNinja, Enemy.YellowNinja};
        String playerFilename = "player.png";
        String swordFilename = "sword.png";
        final String highScoreTextFile = "highscores.txt";

        final GameCourt court = new GameCourt(stageFilenames, enemyTypes, playerFilename, 
                swordFilename, highScoreTextFile);
    
        frame.add(court, BorderLayout.CENTER);
        
        final JTextField textField = new JTextField(20);
        final JPanel panel = new JPanel();
        final JLabel nameButtonLabel = new JLabel();
        nameButtonLabel.setText("Set Name");
        final JButton setNameButton = new JButton();
        setNameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                if (court.playerWon()) {
                    court.updateHighScores(textField.getText());
                    court.toTitleScreen();
                    court.requestFocus();
                }
            }
        });
        textField.addKeyListener(new KeyListener() {
            private void loseFocus(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER || !court.playerWon()) {
                    court.requestFocus();
                }
            }
            @Override
            public void keyTyped(KeyEvent e) {
                loseFocus(e);
            }

            @Override
            public void keyPressed(KeyEvent e) {
                loseFocus(e);
            }

            @Override
            public void keyReleased(KeyEvent e) {
                loseFocus(e);
            }
        });
        setNameButton.add(nameButtonLabel);
        panel.add(textField, BorderLayout.WEST);
        panel.add(setNameButton, BorderLayout.EAST);

        frame.add(panel, BorderLayout.SOUTH);
            
        
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Game());
    }

}