
public enum Enemy {
    RedNinja, BlueNinja, YellowNinja; 
}
